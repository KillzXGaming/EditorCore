﻿using ExtensionMethods;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Media3D;
using LibEveryFileExplorer.Collections;

namespace LibEveryFileExplorer._3D
{
	public class Triangle
	{
		public Triangle(Vector3 A, Vector3 B, Vector3 C)
		{
			PointA = A;
			PointB = B;
			PointC = C;
		}

		public ushort Collision { get; set; }

		public Vector3 PointA { get; internal set; }
		public Vector3 PointB { get; internal set; }
		public Vector3 PointC { get; internal set; }

		public Vector3 Normal
		{
			get
			{
                Vector3 a = (PointB - PointA).Cross(PointC - PointA);
                return a / (float)System.Math.Sqrt(a.X * a.X + a.Y * a.Y + a.Z * a.Z);
            }
		}
    }
}
