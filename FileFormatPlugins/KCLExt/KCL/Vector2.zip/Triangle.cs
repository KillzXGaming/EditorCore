﻿using ExtensionMethods;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Media3D;
using LibEveryFileExplorer.Collections;

namespace LibEveryFileExplorer._3D
{
	public class Triangle
	{
		public Triangle(Vector3D A, Vector3D B, Vector3D C)
		{
			PointA = A;
			PointB = B;
			PointC = C;
		}

		public ushort Collision { get; set; }

		public Vector3D PointA { get; internal set; }
		public Vector3D PointB { get; internal set; }
		public Vector3D PointC { get; internal set; }

		public Vector3D Normal
		{
			get
			{
                Vector3 a = (ToVec3(PointB) - ToVec3(PointA)).Cross(ToVec3(PointC) - ToVec3(PointA));
                Vector3 NEW = a / (float)System.Math.Sqrt(a.X * a.X + a.Y * a.Y + a.Z * a.Z);

                return new Vector3D(NEW.X, NEW.Y, NEW.Z);
            }
		}

        private Vector3 ToVec3(Vector3D v)
        {
            return new Vector3((float)v.X, (float)v.Y, (float)v.Z);
        }
    }
}
